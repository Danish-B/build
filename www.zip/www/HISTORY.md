# History

* Version:1.2.1 - Date: 2015-08-03
* Added versions to all plugins
