# phonegap-contact-test
A simple test of phonegap's Contact plugin.


- v1.3.0 - upgraded plugin and compiler (cli-5.2.0)
    - contacts=1.1.0
    - device=1.0.1


Google Policy on User Data<br>
https://play.google.com/about/privacy-and-security.html#user-data

